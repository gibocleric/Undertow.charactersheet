# Undertow Character Builder

Upload `index.html`, the `fonts` folder, and the included image assets together to the root of your GitHub repository.

Saved characters are stored in the player's current browser on that device. They are not shared between browsers or devices.
